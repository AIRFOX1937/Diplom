﻿using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.DataBase
{
    public class Harvest
    {
        public int Id { get; set; }
        public int SowingId { get; set; }
        public double Quantity { get; set; }
        public QualityType Quality { get; set; }
        public double Price { get; set; }
        public bool IsDeleted { get; set; }

        public required Sowing Sowing { get; set; }

        public ICollection<Warehouse>? Warehouses { get; set; }


        public string GetImage
        {
            get
            {
                string curDir = Directory.GetCurrentDirectory();
                string thisDir = System.IO.Path.Combine(Directory.GetParent(Directory.GetParent(Directory.GetParent(curDir).ToString()).ToString()).ToString(), "Resources\\");

                var sowing = SowingsManager.GetAll().First(x => x.Id == SowingId);

                return thisDir + sowing.CropType + ".jpg";
            }
        }

        public string GetCropType
        {
            get
            {
                var sowing = SowingsManager.GetAll().First(x => x.Id == SowingId);
                return sowing.CropType;
            }
        }

        public string GetQuantity
        {
            get
            {
                return "Объем собранной продукции: " + Quantity + " килограм";
            }
        }

        public string GetQuality
        {
            get
            {
                return "Качество продукции: " + Quality;
            }
        }
        public string GetQualityForBuyers
        {
            get
            {
                return Quality.ToString();
            }
        }

        public string GetPrice
        {
            get
            {
                return "Цена за ед.: " + Price + "руб.";
            }
        }
    }

    public enum QualityType
    {
        Низкое,
        Среднее,
        Высокое
    }
}
