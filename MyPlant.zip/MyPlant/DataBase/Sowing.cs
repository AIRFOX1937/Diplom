﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.DataBase
{
	public class Sowing
	{
		public int Id { get; set; }
		public int EntrepreneurId { get; set; }
		public required string CropType { get; set; }
		public DateTime Date { get; set; }
		public double Area { get; set; }
		public bool IsDeleted { get; set; }

		public Entrepreneur? Entrepreneur { get; set; }

		public ICollection<Harvest>? Harvests { get; set; }

		public string GetImage
		{
			get
			{
                string curDir = Directory.GetCurrentDirectory();
                string thisDir = System.IO.Path.Combine(Directory.GetParent(Directory.GetParent(Directory.GetParent(curDir).ToString()).ToString()).ToString(), "Resources\\");

				return thisDir + CropType + ".jpg";
            }
		}

		public string GetCropType
		{
			get
			{
				return "Сельхоз продукция: " + CropType;
			}
		}

		public string GetDateTime
		{
			get
			{
				return Date.ToLongDateString();
			}
		}

        public string GetArea
		{
			get
			{
				return Area + " гектар";
			}
		}
    }

}
