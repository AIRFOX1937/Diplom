﻿using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.DataBase
{
	public class Warehouse
	{
		public int Id { get; set; }
		public int EntrepreneurId { get; set; }
		public int HarvestId { get; set; }
		public double Quantity { get; set; }
		public DateTime StartDate { get; set; }
        public bool IsDeleted { get; set; }

		public Entrepreneur? Entrepreneur { get; set; }
		public Harvest Harvest { get; set; }

		public ICollection<Order>? Orders { get; set; }

        public string GetImage
        {
            get
            {
                var harvest = HarvestsManager.GetAll().First(x => x.Id == HarvestId);
                return harvest.GetImage;
            }
        }

        public string GetCropType
        {
            get
            {
                var harvest = HarvestsManager.GetAll().First(x => x.Id == HarvestId);
                return harvest.GetCropType;
            }
        }

        public string GetQuantity
        {
            get
            {
                return "Количество продукции: " + Quantity + " килограмм";
            }
        }
        public string GetQuantityForBuyers
        {
            get
            {
                return Quantity.ToString();
            }
        }

        public string GetQuality
        {
            get
            {
                var harvest = HarvestsManager.GetAll().First(x => x.Id == HarvestId);
                return harvest.GetQuality;
            }
        }
        public string GetQualityForBuyers
        {
            get
            {
                var harvest = HarvestsManager.GetAll().First(x => x.Id == HarvestId);
                return harvest.GetQualityForBuyers;
            }
        }

        public string GetStartDate
        {
            get
            {
                return "На продаже с " + StartDate.ToLongDateString();
            }
        }

        public string GetPrice
        {
            get
            {
                var harvest = HarvestsManager.GetAll().First(x => x.Id == HarvestId);
                return "Цена за ед. " + harvest.Price + " руб.";
            }
        }
        public string GetPriceForBuyers
        {
            get
            {
                var harvest = HarvestsManager.GetAll().First(x => x.Id == HarvestId);
                return harvest.Price.ToString();
            }
        }
        public string GetBtnName
        {
            get
            {
                return "BtnAddCard-" + Id.ToString();
            }
        }
    }
}
