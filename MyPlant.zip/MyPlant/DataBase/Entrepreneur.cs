﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.DataBase
{
	public class Entrepreneur
	{
		public int Id { get; set; }
		public int UserId { get; set; }
		public bool IsConfirmation { get; set; }
		public string? Name { get; set; }
		public int? CityId { get; set; }
		public string? Street { get; set; }
		public string? House {  get; set; }

		public required User User { get; set; }
		public City? city { get; set; }

		public required ICollection<Order> Orders { get; set; }
		public required ICollection<Warehouse> Warehouses { get; set; }
		public required ICollection<Sowing> Sowings { get; set; }
	}
}
