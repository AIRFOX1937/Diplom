﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.DataBase
{
	public class ApplicationContext : DbContext
	{
		public ApplicationContext()
		{
			//Database.EnsureDeleted();
			Database.EnsureCreated();
		}

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseNpgsql(@"Host=ep-restless-boat-a27l2nds.eu-central-1.aws.neon.tech;Port=5432;Database=plantsdb;Username=wqpoyr;Password=7v8dzLFCSwAR;SSL Mode=Require;Trust Server Certificate=true");
		}

		public DbSet<User> Users { get; set; }
		public DbSet<Role> Roles { get; set; }
		public DbSet<Entrepreneur> Entrepreneurs { get; set; }
		public DbSet<Harvest> Harvests { get; set; }
		public DbSet<Order> Orders { get; set; }
		public DbSet<Sowing> Sowings { get; set; }
		public DbSet<Warehouse> Warehouses { get; set; }
		public DbSet<City> Cities { get; set; }
		public DbSet<Region> Regions { get; set; }

	}
}
