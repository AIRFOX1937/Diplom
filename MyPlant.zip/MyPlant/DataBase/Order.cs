﻿using MyPlant.Models;
using MyPlant.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace MyPlant.DataBase
{
	public class Order
	{
		public int Id { get; set; }
		public int EntrepreneurId { get; set; }
		public int WarehouseId { get; set; }
		public int UserId { get; set; }
		public DateTime Date { get; set; }
		public double Quantity { get; set; }
		public bool IsProcessed { get; set; }

		public Entrepreneur? Entrepreneur { get; set; }
		public Warehouse? Warehouse { get; set; }
        public User? User { get; set; }

        public string GetImage
        {
            get
            {
                var wh = WarehouseManager.GetAll().First(x => x.Id == WarehouseId);
                return wh.GetImage;
            }
        }

		public string GetCropType
		{
            get
            {
                var wh = WarehouseManager.GetAll().First(x => x.Id == WarehouseId);
                return wh.GetCropType;
            }
        }

        public string GetQuantity
        {
            get
            {
                return Quantity.ToString();
            }
        }

        public string GetPrice
        {
            get
            {
                var wh = WarehouseManager.GetAll().First(x => x.Id == WarehouseId);

                return (Convert.ToDouble(wh.GetPriceForBuyers) * Quantity).ToString();
            }
        }

        public string GetIsProcessed
        {
            get
            {
                if (IsProcessed == false)
                    return "Не обработан";
                else
                    return "Обработан";
            }
        }

        public string GetDateTime
        {
            get
            {
                return Date.ToLocalTime().ToString();
            }
        }

        public string GetBuyerEmail
        {
            get
            {
                var user = UsersManager.SearchUser(UserId, null, null, "id");
                return user.Email;
            }
        }

        public StackPanel GetButton
        {
            get
            {
                var stck = new StackPanel();
                if (IsProcessed == false)
                {
                    var button = new Button() { Content = "Подтвердить", Background = Brushes.Gold, BorderThickness = new System.Windows.Thickness(1), FontSize = 18, Foreground = Brushes.Black, FontWeight = FontWeights.Bold };
                    button.Click += Button_Click;
                    stck.Children.Add(button);
                    return stck;
                }
                else
                {
                    return stck;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            MainWindow window = (MainWindow)Window.GetWindow(btn);

            Order selectedOrder = (sender as FrameworkElement).DataContext as Order;

            if (OrdersManager.SetIsProcessed(selectedOrder.Id))
            {
                MessageBox.Show("Покупка успешно подтверждена!");
                window.LstViewBuyerList.ItemsSource = OrdersManager.GetAllForSeller(window.currentuser.Id);
            }
        }
    }
}
