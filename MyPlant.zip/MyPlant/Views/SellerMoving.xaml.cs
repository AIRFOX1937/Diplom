﻿using MyPlant.DataBase;
using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
    /// <summary>
    /// Interaction logic for SellerMoving.xaml
    /// </summary>
    public partial class SellerMoving : Window
    {
        public Sowing sowing;
        public MainWindow mw;
        public SellerMoving(MainWindow _mw, Sowing _sowing)
        {
            InitializeComponent();
            sowing = _sowing;
            mw = _mw;
        }

        private void BtnMoveToHarvest_Click(object sender, RoutedEventArgs e)
        {
            if (HarvestsManager.Add(sowing.Id, Convert.ToDouble(TxtQuantity.Text), CmbQuality.SelectedIndex, Convert.ToDouble(TxtPrice.Text)))
            {
                MessageBox.Show($"{sowing.CropType} теперь является урожаем!");
                SowingsManager.SetDeleted(sowing.Id);
                mw.LstViewSowings.ItemsSource = SowingsManager.GetCurrentAll(mw.currentuser.Id);
                Close();
            }
            else
                MessageBox.Show("Ошибка");
        }

        private void BtnCloseWindow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Close();
        }
    }
}
