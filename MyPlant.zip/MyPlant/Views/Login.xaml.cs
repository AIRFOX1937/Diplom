﻿using MyPlant.DataBase;
using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
	/// <summary>
	/// Логика взаимодействия для Login.xaml
	/// </summary>
	public partial class Login : Window
	{
		private readonly ApplicationContext db = new ApplicationContext();
		public Login()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{

        }

		private void BtnExit_Click(object sender, RoutedEventArgs e)
		{
            App.Current.Shutdown();
		}

		private void BtnLogin_Click(object sender, RoutedEventArgs e)
		{
			TxtPassword.Text = PswPassword.Password;

			var user = UsersManager.SearchUser(null, TxtEmail.Text, TxtPassword.Text, "emailpassword");

            if (user != null)
			{
				MessageBox.Show("Успешная авторизация!", "MyPlant");
				var mw = new MainWindow(user);
				mw.Show();
				Hide();
			}
			else
				MessageBox.Show("Неудачная авторизация!", "MyPlant");
		}

		private void ImgShowPass_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			ShowPassword();
		}

		private void ImgShowPass_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			HidePassword();
		}

		private void ImgShowPass_MouseLeave(object sender, MouseEventArgs e)
		{
			HidePassword();
		}

		void ShowPassword()
		{
			TxtPassword.Visibility = Visibility.Visible;
			PswPassword.Visibility = Visibility.Collapsed;
			TxtPassword.Text = PswPassword.Password;
		}
		void HidePassword()
		{
			TxtPassword.Visibility = Visibility.Collapsed;
			PswPassword.Visibility = Visibility.Visible;
			PswPassword.Focus();
		}

        private void BtnOpenRecovery_Click(object sender, RoutedEventArgs e)
        {
            Recovery rc = new();
            Close();
            rc.Show();
        }

        private void BtnOpenRegistration_Click(object sender, RoutedEventArgs e)
        {
            Register rg = new();
            Close();
            rg.Show();
        }

        private void BtnOpenLogin_Click(object sender, RoutedEventArgs e)
        {
            Login lg = new();
            Close();
            lg.Show();
        }
    }
}
