﻿using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
    /// <summary>
    /// Interaction logic for Recovery.xaml
    /// </summary>
    public partial class Recovery : Window
    {
        public int sendedcode = 0;
        public Recovery()
        {
            InitializeComponent();
        }

        private void BtnSendEmailForRecovery_Click(object sender, RoutedEventArgs e)
        {
            int code = ContextManager.GenerateRecoveryCode();
            sendedcode = code;
            ContextManager.SendMessageToEmail(TxtEmail.Text, "Восстановление пароля", $"Здравствуйте, вам отправлен код для восстановления пароля: <b>{code}<b>");

            GrdPass.Visibility = Visibility.Visible;
            BtnUpdatePassword.Visibility = Visibility.Visible;

            TxtEmail.IsEnabled = false;
            BtnSendEmailForRecovery.IsEnabled = false;
        }

        private void BtnUpdatePassword_Click(object sender, RoutedEventArgs e)
        {
            TxtPassword.Text = PswPassword.Password;
            if (int.Parse(TxtEmailCode.Text) == sendedcode)
            {
                var user = UsersManager.SearchUser(null, TxtEmail.Text, null, "email");

                if (user != null && UsersManager.UpdatePassword(user.Id, TxtPassword.Text))
                {
                    MessageBox.Show("Пароль успешно изменен");
                    Login lg = new();
                    Close();
                    lg.Show();
                }
                else
                    MessageBox.Show("Произошла ошибка!");
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        void ShowPassword()
        {
            TxtPassword.Visibility = Visibility.Visible;
            PswPassword.Visibility = Visibility.Collapsed;
            TxtPassword.Text = PswPassword.Password;
        }
        void HidePassword()
        {
            TxtPassword.Visibility = Visibility.Collapsed;
            PswPassword.Visibility = Visibility.Visible;
            PswPassword.Focus();
        }

        private void ImgShowPass_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            ShowPassword();
        }

        private void ImgShowPass_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            HidePassword();
        }

        private void ImgShowPass_MouseLeave(object sender, MouseEventArgs e)
        {
            HidePassword();
        }

        private void BtnOpenRecovery_Click(object sender, RoutedEventArgs e)
        {
            Recovery rc = new();
            Close();
            rc.Show();
        }

        private void BtnOpenRegistration_Click(object sender, RoutedEventArgs e)
        {
            Register rg = new();
            Close();
            rg.Show();
        }

        private void BtnOpenLogin_Click(object sender, RoutedEventArgs e)
        {
            Login lg = new();
            Close();
            lg.Show();
        }
    }
}
