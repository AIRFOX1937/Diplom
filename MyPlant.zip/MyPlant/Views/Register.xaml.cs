﻿using MyPlant.DataBase;
using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
	/// <summary>
	/// Логика взаимодействия для Register.xaml
	/// </summary>
	public partial class Register : Window
	{
		public Register()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{

        }

		private void BtnExit_Click(object sender, RoutedEventArgs e)
		{
			Application.Current.Shutdown();
		}

		private void BtnRegister_Click(object sender, RoutedEventArgs e)
		{
			if (UsersManager.SearchUser(null, TxtEmail.Text, null, "email") == null)
			{
				TxtPassword.Text = PswPassword.Password;
				if (UsersManager.CreateUser(TxtEmail.Text, TxtPassword.Text, 2))
				{
					MessageBox.Show("Регистрация прошла успешно!", "MyPlant");
					Login login = new();
					Close();
					login.Show();
				}
				else
					MessageBox.Show("Произошла ошибка в регистрации!", "MyPlant");
			}
			else
			{
				MessageBox.Show("Пользователь с таким адресом электронной почты уже зарегистрирован!", "MyPlant");
			}
		}

		private void ImgShowPass_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			ShowPassword();
		}

		void ShowPassword()
		{
			TxtPassword.Visibility = Visibility.Visible;
			PswPassword.Visibility = Visibility.Collapsed;
			TxtPassword.Text = PswPassword.Password;
		}
		void HidePassword()
		{
			TxtPassword.Visibility = Visibility.Collapsed;
			PswPassword.Visibility = Visibility.Visible;
			PswPassword.Focus();
		}

		private void ImgShowPass_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			HidePassword();
		}

		private void ImgShowPass_MouseLeave(object sender, MouseEventArgs e)
		{
			HidePassword();
		}

        private void BtnOpenLogin_Click(object sender, RoutedEventArgs e)
        {
            Login lg = new();
            Close();
            lg.Show();
        }

        private void BtnOpenRegistration_Click(object sender, RoutedEventArgs e)
        {
            Register rg = new();
            Close();
            rg.Show();
        }

        private void BtnOpenRecovery_Click(object sender, RoutedEventArgs e)
        {
            Recovery rc = new();
            Close();
            rc.Show();
        }
    }
}
