﻿using MyPlant.DataBase;
using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public readonly User currentuser;
		public MainWindow(User user)
		{
			InitializeComponent();
			currentuser = user;

            SetLeftBar();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            Close();
            login.Show();
        }

        private void CmbChangeType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem typeItem = (ComboBoxItem)CmbChangeType.SelectedItem;
			LblHistory.Content = "История " + typeItem.Content.ToString();

            if (CmbChangeType.SelectedIndex == 0)
            {
                LstViewSowings.Visibility = Visibility.Visible;
                LstViewHarvests.Visibility = Visibility.Collapsed;
                LstViewWarehouse.Visibility = Visibility.Collapsed;
                BtnAddition.Visibility = Visibility.Visible;

                LstViewSowings.ItemsSource = SowingsManager.GetCurrentAll(currentuser.Id);
            }
            else if (CmbChangeType.SelectedIndex == 1)
            {
                LstViewSowings.Visibility = Visibility.Collapsed;
                LstViewHarvests.Visibility = Visibility.Visible;
                LstViewWarehouse.Visibility = Visibility.Collapsed;
                BtnAddition.Visibility = Visibility.Collapsed;

                LstViewHarvests.ItemsSource = HarvestsManager.GetCurrentAll();
            }
            else if (CmbChangeType.SelectedIndex == 2)
            {
                LstViewSowings.Visibility = Visibility.Collapsed;
                LstViewHarvests.Visibility = Visibility.Collapsed;
                LstViewWarehouse.Visibility = Visibility.Visible;
                BtnAddition.Visibility = Visibility.Collapsed;

                LstViewWarehouse.ItemsSource = WarehouseManager.GetCurrentAll();
            }
        }

        private void BtnAddition_Click(object sender, RoutedEventArgs e)
        {
            SellerAddition sa = new(this, currentuser.Id);
            sa.Show();
        }

        private void BtnMoveToHarvest_Click(object sender, RoutedEventArgs e)
        {
            Sowing _sowing = (sender as Button).DataContext as Sowing;

            SellerMoving sm = new SellerMoving(this, _sowing);
            sm.Show();
        }

        private void BtnMoveToWarehouse_Click(object sender, RoutedEventArgs e)
        {
            Harvest _harvest = (sender as Button).DataContext as Harvest;

            if (WarehouseManager.Add(EntrepreneurManager.GetEntrepreneurByUserId(currentuser.Id).Id, _harvest.Id, _harvest.Quantity))
            {
                MessageBox.Show($"{_harvest.GetCropType} перемещен на склад!");
                HarvestsManager.SetDeleted(_harvest.Id);
                LstViewHarvests.ItemsSource = HarvestsManager.GetCurrentAll();
            }
            else
                MessageBox.Show("Ошибка!");
        }

        private void BtnProfile_Click(object sender, RoutedEventArgs e)
        {
            DpnlAccount.Visibility = Visibility.Visible;
            DpnlActions.Visibility = Visibility.Collapsed;
            DpnlSummary.Visibility = Visibility.Collapsed;
            DpnlBuy.Visibility = Visibility.Collapsed;
            DpnlBuyersList.Visibility = Visibility.Collapsed;
            UpdateProfileInfo();
            CmbRegion.ItemsSource = RegionsManager.GetAll();
            CmbRegion.DisplayMemberPath = "Name";
        }

        private void BtnActions_Click(object sender, RoutedEventArgs e)
        {
            DpnlAccount.Visibility = Visibility.Collapsed;
            DpnlActions.Visibility = Visibility.Visible;
            DpnlSummary.Visibility = Visibility.Collapsed;
            DpnlBuy.Visibility = Visibility.Collapsed;
            DpnlBuyersList.Visibility = Visibility.Collapsed;
        }

        public void UpdateProfileInfo()
        {
            var entrep = EntrepreneurManager.GetEntrepreneurByUserId(currentuser.Id);

            LblCompanyName.Content = entrep.Name;
            TxtCompanyName.Text = entrep.Name;

            if (entrep.CityId != null)
            {
                LblRegion.Content = RegionsManager.GetRegionById(CitiesManager.GetCityById((int)entrep.CityId).RegionId).Name;
                LblCity.Content = CitiesManager.GetCityById((int)entrep.CityId).Name;
            }
            LblStreet.Content = entrep.Street;
            TxtStreet.Text = entrep.Street;
            LblHouse.Content = entrep.House;
            TxtHouse.Text = entrep.House;
        }

        private void CmbRegion_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedregion = (Region)CmbRegion.SelectedItem;

            CmbCity.ItemsSource = CitiesManager.GetCitiesByRegionId(selectedregion.Id);
            CmbCity.DisplayMemberPath = "Name";
        }

        private void BtnEditProfile_Click(object sender, RoutedEventArgs e)
        {
            if (BtnEditProfile.Content.ToString() == "Изменить")
            {
                LblCompanyName.Visibility = Visibility.Collapsed;
                TxtCompanyName.Visibility = Visibility.Visible;

                LblRegion.Visibility = Visibility.Collapsed;
                CmbRegion.Visibility = Visibility.Visible;

                LblCity.Visibility = Visibility.Collapsed;
                CmbCity.Visibility = Visibility.Visible;

                LblStreet.Visibility = Visibility.Collapsed;
                TxtStreet.Visibility = Visibility.Visible;

                LblHouse.Visibility = Visibility.Collapsed;
                TxtHouse.Visibility = Visibility.Visible;

                BtnEditProfile.Content = "Сохранить";
            }
            else if (BtnEditProfile.Content.ToString() == "Сохранить")
            {
                LblCompanyName.Visibility = Visibility.Visible;
                TxtCompanyName.Visibility = Visibility.Collapsed;

                LblRegion.Visibility = Visibility.Visible;
                CmbRegion.Visibility = Visibility.Collapsed;

                LblCity.Visibility = Visibility.Visible;
                CmbCity.Visibility = Visibility.Collapsed;

                LblStreet.Visibility = Visibility.Visible;
                TxtStreet.Visibility = Visibility.Collapsed;

                LblHouse.Visibility = Visibility.Visible;
                TxtHouse.Visibility = Visibility.Collapsed;

                BtnEditProfile.Content = "Изменить";

                var city = (City)CmbCity.SelectedItem;

                if (EntrepreneurManager.UpdatePersonal(currentuser.Id, TxtCompanyName.Text, city.Id, TxtStreet.Text, TxtHouse.Text))
                {
                    MessageBox.Show("Информация о компании успешно обновлена!");
                    UpdateProfileInfo();
                }
                else
                    MessageBox.Show("Ошибка");
            }
        }

        private void BtnSummary_Click(object sender, RoutedEventArgs e)
        {
            DpnlAccount.Visibility = Visibility.Collapsed;
            DpnlActions.Visibility = Visibility.Collapsed;
            DpnlSummary.Visibility = Visibility.Visible;
            DpnlBuy.Visibility = Visibility.Collapsed;
            DpnlBuyersList.Visibility = Visibility.Collapsed;

            UpdateEntrepreneurSummary();
        }

        public void UpdateEntrepreneurSummary()
        {
            LblCurrentSowing.Content = SowingsManager.GetListByUserId(currentuser.Id).Count(x => x.IsDeleted == false);
            LblAllSowing.Content = SowingsManager.GetCountByUserId(currentuser.Id);
            LblCurrentHarvest.Content = HarvestsManager.GetListByUserId(currentuser.Id).Count(x => x.IsDeleted == false);
            LblAllHarvest.Content = HarvestsManager.GetCountByUserId(currentuser.Id);
            LblAllWarehouse.Content = WarehouseManager.GetCountByUserId(currentuser.Id);
            LblAllOrder.Content = OrdersManager.GetCountForSeller(currentuser.Id);
        }

        private void BtnBuy_Click(object sender, RoutedEventArgs e)
        {
            LstViewItems.ItemsSource = WarehouseManager.GetCurrentAll();

            DpnlBuy.Visibility = Visibility.Visible;
            DpnlBuyerPtofile.Visibility = Visibility.Collapsed;
        }

        private void BtnSearchItems_Click(object sender, RoutedEventArgs e)
        {
            var selectquality = (ComboBoxItem)CmbSrcQuality.SelectedItem;

            if(selectquality != null && TxtSrcCropType.Text != string.Empty && TxtSrcQuantity.Text != string.Empty && TxtSrcPrice.Text != string.Empty)
            {
                LstViewItems.ItemsSource = WarehouseManager.GetCurrentAll().Where(x => x.Quantity > Convert.ToDouble(TxtSrcQuantity.Text) && Convert.ToDouble(x.GetPriceForBuyers) < Convert.ToDouble(TxtSrcPrice.Text) && x.GetCropType == TxtSrcCropType.Text && x.GetQualityForBuyers == selectquality.Content.ToString()).ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Warehouse selectedWarehouse = (sender as FrameworkElement).DataContext as Warehouse;

            AddOrder ao = new(this, EntrepreneurManager.GetEntrepreneurByWarehouseId(selectedWarehouse.Id).Id, selectedWarehouse.Id, currentuser.Id, selectedWarehouse.Quantity);
            ao.Show();
        }

        public void SetLeftBar()
        {
            if (currentuser.RoleId == 1)
            {
                LstItemSellerProfile.Visibility = Visibility.Visible;
                LstItemSellerActions.Visibility = Visibility.Visible;
                LstItemSellerSummary.Visibility = Visibility.Visible;
                LstItemSellerOrders.Visibility = Visibility.Visible;
                LstItemBuyerCatalog.Visibility = Visibility.Collapsed;
                LstItemBuyerProfile.Visibility = Visibility.Collapsed;
                LstItemAdministration.Visibility = Visibility.Collapsed;

                DpnlAccount.Visibility = Visibility.Visible;

                UpdateProfileInfo();
                CmbRegion.ItemsSource = RegionsManager.GetAll();
                CmbRegion.DisplayMemberPath = "Name";
            }
            else if (currentuser.RoleId == 2)
            {
                LstItemSellerProfile.Visibility = Visibility.Collapsed;
                LstItemSellerActions.Visibility = Visibility.Collapsed;
                LstItemSellerSummary.Visibility = Visibility.Collapsed;
                LstItemSellerOrders.Visibility = Visibility.Collapsed;
                LstItemBuyerCatalog.Visibility = Visibility.Visible;
                LstItemBuyerProfile.Visibility = Visibility.Visible;
                LstItemAdministration.Visibility = Visibility.Collapsed;

                DpnlBuy.Visibility = Visibility.Visible;
                LstViewItems.ItemsSource = WarehouseManager.GetCurrentAll();
            }
            else if (currentuser.RoleId == 3)
            {
                LstItemSellerProfile.Visibility = Visibility.Collapsed;
                LstItemSellerActions.Visibility = Visibility.Collapsed;
                LstItemSellerSummary.Visibility = Visibility.Collapsed;
                LstItemSellerOrders.Visibility = Visibility.Collapsed;
                LstItemBuyerCatalog.Visibility = Visibility.Collapsed;
                LstItemBuyerProfile.Visibility = Visibility.Collapsed;
                LstItemAdministration.Visibility = Visibility.Visible;

                DpnlAdmin.Visibility = Visibility.Visible;
            }
        }

        private void BtnBuyerProfile_Click(object sender, RoutedEventArgs e)
        {
            DpnlBuyerPtofile.Visibility = Visibility.Visible;
            DpnlBuy.Visibility = Visibility.Collapsed;
            LblEmailBuyerUser.Content = currentuser.Email;

            LstViewPurchases.ItemsSource = OrdersManager.GetAll(currentuser.Id);
        }

        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            DpnlAccount.Visibility = Visibility.Collapsed;
            DpnlActions.Visibility = Visibility.Collapsed;
            DpnlSummary.Visibility = Visibility.Collapsed;
            DpnlBuy.Visibility = Visibility.Collapsed;
            DpnlBuyersList.Visibility = Visibility.Visible;
            LstViewBuyerList.ItemsSource = OrdersManager.GetAllForSeller(currentuser.Id);
        }

        private void BtnAdmin_Click(object sender, RoutedEventArgs e)
        {
            DpnlAdmin.Visibility = Visibility.Visible;
        }

        private void BtnAddEntrep_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if ((bool)RdbtnConfirmY.IsChecked)
                    EntrepreneurManager.Add(TxtEntrepEmail.Text, true);
                else if ((bool)RdbtnConfirmN.IsChecked)
                    EntrepreneurManager.Add(TxtEntrepEmail.Text, false);

                MessageBox.Show("Аккаунт предпринимателя успешно создан!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
