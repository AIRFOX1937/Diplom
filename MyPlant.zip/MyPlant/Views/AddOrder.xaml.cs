﻿using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
    /// <summary>
    /// Interaction logic for AddOrder.xaml
    /// </summary>
    public partial class AddOrder : Window
    {
        readonly MainWindow mw;
        readonly int entrepreneurid = 0;
        readonly int whid = 0;
        readonly int userid = 0;
        readonly double maxquantity = 0;
        public AddOrder(MainWindow _mw, int entrepid, int wh, int _userid, double _maxquantity)
        {
            InitializeComponent();
            mw = _mw;
            entrepreneurid = entrepid;
            whid = wh;
            userid = _userid;
            maxquantity = _maxquantity;
        }

        private void BtnCloseWindow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Close();
        }

        private void BtnBuy_Click(object sender, RoutedEventArgs e)
        {
            if (maxquantity < Convert.ToDouble(TxtQuantity.Text))
            {
                MessageBox.Show($"Для покупки доступно только {maxquantity} килограм");
            }
            else
            {
                if (OrdersManager.Add(entrepreneurid, whid, Convert.ToDouble(TxtQuantity.Text), userid))
                {
                    WarehouseManager.SubtractQuantity(whid, Convert.ToDouble(TxtQuantity.Text));
                    MessageBox.Show("Предзаказ успешно оформлен!");
                    mw.LstViewItems.ItemsSource = WarehouseManager.GetCurrentAll();
                    Close();
                }
                else
                    MessageBox.Show("Произошла ошибка!");
            }


        }
    }
}
