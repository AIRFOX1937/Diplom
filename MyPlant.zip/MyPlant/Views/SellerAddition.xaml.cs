﻿using MyPlant.DataBase;
using MyPlant.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyPlant.Views
{
    /// <summary>
    /// Interaction logic for SellerAddition.xaml
    /// </summary>
    public partial class SellerAddition : Window
    {
        public string thisDir = string.Empty;

        public Entrepreneur entrep;
        public MainWindow mw;

        public SellerAddition(MainWindow _mw, int userid)
        {
            InitializeComponent();

            string curDir = Directory.GetCurrentDirectory();
            thisDir = System.IO.Path.Combine(Directory.GetParent(Directory.GetParent(Directory.GetParent(curDir).ToString()).ToString()).ToString(), "Resources\\");

            entrep = EntrepreneurManager.GetEntrepreneurByUserId(userid);
            mw = _mw;
        }

        private void BtnAddSowing_Click(object sender, RoutedEventArgs e)
        {
            if (SowingsManager.Add(entrep.Id, TxtCropType.Text, int.Parse(TxtArea.Text), entrep))
            {
                MessageBox.Show("Посев успешно добавлен!");
                mw.LstViewSowings.ItemsSource = SowingsManager.GetCurrentAll(entrep.UserId);
                Close();
            }
            else
            {
                MessageBox.Show("Не получилось");
            }
        }

        private void TxtCropType_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (File.Exists(thisDir + TxtCropType.Text + ".jpg"))
            {
                BitmapImage bitmap = new BitmapImage(new Uri(thisDir + TxtCropType.Text + ".jpg"));
                ImgItem.Source = bitmap;
            }
            else
            {
                ImgItem.Source = null;
            }
        }

        private void BtnCloseWindow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Close();
        }

        private void BtnAddHarvest_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
