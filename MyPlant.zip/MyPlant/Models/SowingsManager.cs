﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.Models
{
    public class SowingsManager
    {
        private static readonly ApplicationContext db = new();

        /// <summary>
        /// Добавление нового посева
        /// </summary>
        /// <param name="intrepreneurid"></param>
        /// <param name="croptype"></param>
        /// <param name="area"></param>
        /// <returns></returns>
        public static bool Add(int intrepreneurid, string croptype, int area, Entrepreneur entrep)
        {
            try
            {
                var sowing = new Sowing()
                {
                    EntrepreneurId = intrepreneurid,
                    CropType = croptype,
                    Date = DateTime.UtcNow,
                    Area = area
                };

                db.Sowings.Add(sowing);
                db.SaveChanges();

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<Sowing> GetCurrentAll(int userid)
        {
            return db.Sowings.Where(x => x.IsDeleted == false && x.EntrepreneurId == EntrepreneurManager.GetEntrepreneurByUserId(userid).Id).ToList();
        }

        public static List<Sowing> GetAll()
        {
            return db.Sowings.ToList();
        }

        public static void SetDeleted(int sowingid)
        {
            var sowing = db.Sowings.Single(x => x.Id == sowingid);
            sowing.IsDeleted = true;

            db.Sowings.Update(sowing);
            db.SaveChanges();
        }

        public static List<Sowing> GetListByUserId(int userid)
        {
            var entrep = EntrepreneurManager.GetEntrepreneurByUserId(userid);

            return db.Sowings.Where(x => x.EntrepreneurId == entrep.Id).ToList();
        }

        public static int GetCountByUserId(int userid) => GetListByUserId(userid).Count;
    }
}
