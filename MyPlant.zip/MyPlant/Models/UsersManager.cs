﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MyPlant.Models
{
	internal class UsersManager : ContextManager
	{
		private static readonly ApplicationContext db = new();

		/// <summary>
		/// Создание нового пользователя
		/// </summary>
		/// <param name="email"></param>
		/// <param name="password"></param>
		/// <param name="roleid"></param>
		/// <returns></returns>
		public static bool CreateUser(string email, string password, int roleid)
		{
            var newUser = new User()
            {
                Email = email,
                PasswordHash = Hashing(password),
                RoleId = roleid
            };

            db.Users.Add(newUser);
            db.SaveChanges();

            return true;
        }

		/// <summary>
		/// Поиск пользователя по определенным параметрам
		/// </summary>
		/// <param name="id"></param>
		/// <param name="email"></param>
		/// <param name="password"></param>
		/// <param name="type"></param>
		/// <returns></returns>
		public static User? SearchUser(int? id, string? email, string? password, string type)
		{
			if (type == "emailpassword")
			{
				if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(password))
				{
					var user = db.Users.SingleOrDefault(x => x.Email == email && x.PasswordHash == Hashing(password));
					return user;
				}
				else
					return null;
			}
			else if (type == "email")
			{
				if (!string.IsNullOrEmpty(email))
				{
					var user = db.Users.FirstOrDefault(x => x.Email == email);
					if (user != null)
						return user;
					else
						return null;
				}
				else
					return null;
			}
			else if (type == "id")
			{
				if (id != null)
				{
					var user = db.Users.SingleOrDefault(x => x.Id == id);
					return user;
				}
				else
					return null;
			}
			else
				return null;
		}

		public static bool UpdatePassword(int userid, string password)
		{
			var user = db.Users.Single(x => x.Id == userid);

			if (user != null)
			{
				user.PasswordHash = Hashing(password);
				db.Users.Update(user);
				db.SaveChanges();

				return true;
			}
			else
			{
				return false;
			}
		}
	}
}
