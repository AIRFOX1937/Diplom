﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.Models
{
    public class WarehouseManager
    {
        private static readonly ApplicationContext db = new();
        public static List<Warehouse> GetAll() => db.Warehouses.ToList();
        public static List<Warehouse> GetCurrentAll() => db.Warehouses.Where(x => x.IsDeleted == false).ToList();

        public static bool Add(int entrepreneurid, int harvestid, double quantity)
        {
            var wh = new Warehouse()
            {
                EntrepreneurId = entrepreneurid,
                HarvestId = harvestid,
                Quantity = quantity,
                StartDate = DateTime.UtcNow,
                IsDeleted = false
            };

            db.Warehouses.Add(wh);
            db.SaveChanges();
            return true;
        }

        public static void SubtractQuantity(int warehouseid, double quantity)
        {
            var wh = db.Warehouses.Single(x => x.Id == warehouseid);

            if (wh != null)
            {
                wh.Quantity -= quantity;

                if (wh.Quantity == 0)
                {
                    wh.IsDeleted = true;
                }

                db.Warehouses.Update(wh);
                db.SaveChanges();
            }
        }

        public static List<Warehouse> GetListByUserId(int userid)
        {
            var entrep = EntrepreneurManager.GetEntrepreneurByUserId(userid);
            List<Warehouse> warehouses = db.Warehouses.Where(x => x.EntrepreneurId == entrep.Id && x.IsDeleted == false).ToList();

            return warehouses;
        }

        public static int GetCountByUserId(int userid) => GetListByUserId(userid).Count;
    }
}
