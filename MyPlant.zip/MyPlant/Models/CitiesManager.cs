﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.Models
{
    public class CitiesManager
    {
        private static readonly ApplicationContext db = new();
        public static City GetCityById(int cityid) => db.Cities.Single(x => x.Id == cityid);
        public static List<City> GetCitiesByRegionId(int regionid) => db.Cities.Where(x => x.RegionId == regionid).ToList();
    }
}
