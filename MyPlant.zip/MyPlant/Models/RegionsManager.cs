﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.Models
{
    public class RegionsManager
    {
        private static readonly ApplicationContext db = new();

        public static Region GetRegionById(int regionid) => db.Regions.Single(x => x.Id == regionid);

        public static List<Region> GetAll() => db.Regions.ToList();
    }
}
