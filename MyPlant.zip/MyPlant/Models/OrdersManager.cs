﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.Models
{
    public class OrdersManager
    {
        private static readonly ApplicationContext db = new();

        public static List<Order> GetAll(int userid) => db.Orders.Where(x => x.UserId == userid).ToList();

        public static List<Order> GetAllForSeller(int userid) => db.Orders.Where(x => x.EntrepreneurId == EntrepreneurManager.GetEntrepreneurByUserId(userid).Id).ToList();

        public static int GetCountForSeller(int userid) => GetAllForSeller(userid).Count;

        public static bool Add(int entrepreneurid, int warehouseid, double quantity, int userid)
        {
            try
            {
                var order = new Order()
                {
                    EntrepreneurId = entrepreneurid,
                    WarehouseId = warehouseid,
                    UserId = userid,
                    Date = DateTime.UtcNow,
                    Quantity = quantity,
                    IsProcessed = false
                };

                db.Orders.Add(order);
                db.SaveChanges();

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool SetIsProcessed(int orderid)
        {
            var order = db.Orders.Single(x => x.Id == orderid);

            if (order != null)
            {
                order.IsProcessed = true;

                db.Orders.Update(order);
                db.SaveChanges();

                return true;
            }

            return false;
        }
    }
}
