﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace MyPlant.Models
{
    public class EntrepreneurManager
    {
        private static readonly ApplicationContext db = new();

        public static Entrepreneur GetEntrepreneurByUserId(int userid)
        {
            var entrep = db.Entrepreneurs.Single(x => x.UserId == userid);
            if (entrep != null)
                return entrep;
            else
                return null;
        }

        public static Entrepreneur GetEntrepreneurByWarehouseId(int warehouseid)
        {
            var entrepid = db.Warehouses.Single(x => x.Id == warehouseid).EntrepreneurId;
            var entrep = db.Entrepreneurs.Single(x => x.Id == entrepid);
            if (entrep != null)
                return entrep;
            else
                return null;
        }

        public static bool UpdatePersonal(int userid, string companyname, int cityid, string street, string house)
        {
            var entrep = GetEntrepreneurByUserId(userid);
            
            if (entrep != null)
            {
                entrep.Name = companyname;
                entrep.CityId = cityid;
                entrep.Street = street;
                entrep.House = house;

                db.Entrepreneurs.Update(entrep);
                db.SaveChanges();

                return true;
            }
            else
                return false;
        }

        public static void Add(string email, bool isconfirmation)
        {
            string password = ContextManager.GeneratePassword();

            User user = new()
            {
                Email = email,
                PasswordHash = ContextManager.Hashing(password),
                RoleId = 1
            };

            db.Users.Add(user);
            db.SaveChanges();

            Entrepreneur entrepreneur = new()
            {
                UserId = user.Id,
                IsConfirmation = isconfirmation,
                User = user,
                Orders = db.Orders.ToList(),
                Warehouses = db.Warehouses.ToList(),
                Sowings = db.Sowings.ToList()
            };

            db.Entrepreneurs.Add(entrepreneur);
            db.SaveChanges();

            ContextManager.SendMessageToEmail(email, "Создание аккаунта предпринимателя", $"Здравствуйте, вы оставляли заявку на создание аккаунта предпринимателя.<br>Ваш аккаунт успешно создан!<br><br>Email: <b>{email}</b><br>Пароль: <b>{password}</b>");
        }
    }
}
