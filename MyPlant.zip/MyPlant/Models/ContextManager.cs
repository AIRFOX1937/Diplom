﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using MyPlant.DataBase;
using System.Net.Mail;
using System.Net;

namespace MyPlant.Models
{
	public class ContextManager
	{
		/// <summary>
		/// Метод хэширование пароля
		/// </summary>
		/// <param name="password"></param>
		/// <returns></returns>
		public static string Hashing(string password)
		{
			using (SHA256 sha256 = SHA256.Create())
			{
				byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));

				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < hashBytes.Length; i++)
				{
					builder.Append(hashBytes[i].ToString("x2"));
				}

				return builder.ToString();
			}
		}

		public static QualityType GetQualityByInt(int num)
		{
			switch(num)
			{
				case 0:
					return QualityType.Низкое;
				case 1:
					return QualityType.Среднее;
				case 2:
					return QualityType.Высокое;
				default:
					return QualityType.Среднее;
			}
		}

        public static void SendMessageToEmail(string email, string subject, string body)
        {
            MailAddress from = new MailAddress("ranelgilyazov003@gmail.com", "MyPlant");
            MailAddress to = new MailAddress(email);

            string htmlBody = $@"
            <div style='font-family: Arial, Helvetica, sans-serif;'>
                <div style='text-align:center;'>
                    <h1>Восстановление пароля</h1>
                </div>
                <div>
                    <p style='font-size: 16px; color: #000000 !important'>
                        {body}
                    </p>
                </div>
                <div style='text-align: center; background-color: #31A05F; padding: 16px 32px;'>
                    <p style='color: white; font-size: 20px;'>2024 &#8212; MyPlant</p>
                </div>
            </div>";

            MailMessage message = new MailMessage(from, to)
            {
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true
            };

            SmtpClient smtp = new SmtpClient("smtp.elasticemail.com", 2525);
            smtp.Credentials = new NetworkCredential("myplant@plant.com", "5F5A99F6FE1A3D7C1E2F768B879A3511E858");

            smtp.SendMailAsync(message);
        }

        public static int GenerateRecoveryCode()
        {
            Random rnd = new Random();
            return rnd.Next(1000, 9999);
        }

        public static string GeneratePassword()
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            StringBuilder sb = new StringBuilder(8);
            for (int i = 0; i < 8; i++)
            {
                int index = random.Next(chars.Length);
                sb.Append(chars[index]);
            }
            return sb.ToString();
        }
    }
}
