﻿using MyPlant.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlant.Models
{
    public class HarvestsManager : ContextManager
    {
        private static readonly ApplicationContext db = new();

        public static List<Harvest> GetAll() => db.Harvests.ToList();

        public static List<Harvest> GetCurrentAll() => db.Harvests.Where(x => x.IsDeleted == false).ToList();

        public static bool Add(int sowingid, double quantity, int quality, double price)
        {
            var sowing = db.Sowings.Single(x => x.Id == sowingid);

            Harvest harvest = new()
            {
                SowingId = sowingid,
                Quantity = quantity,
                Quality = GetQualityByInt(quality),
                Price = price,
                IsDeleted = false,
                Sowing = sowing
            };

            db.Harvests.Add(harvest);
            db.SaveChanges();

            return true;
        }

        public static void SetDeleted(int harvestid)
        {
            var harvest = db.Harvests.Single(x => x.Id == harvestid);
            harvest.IsDeleted = true;

            db.Harvests.Update(harvest);
            db.SaveChanges();
        }

        public static int GetCountByUserId(int userid) => GetListByUserId(userid).Count;

        public static List<Harvest> GetListByUserId(int userid)
        {
            var entrep = EntrepreneurManager.GetEntrepreneurByUserId(userid);

            List<Sowing> entrepsows = db.Sowings.Where(x => x.EntrepreneurId == entrep.Id).ToList();
            //List<Harvest> harvestes = db.Harvests.Where(h => entrepsows.Any(e => h.SowingId == e.Id)).ToList();
            List<Harvest> harvestes = db.Harvests.AsEnumerable().Where(h => entrepsows.Any(e => h.SowingId == e.Id)).ToList();

            return harvestes;
        }
    }
}
